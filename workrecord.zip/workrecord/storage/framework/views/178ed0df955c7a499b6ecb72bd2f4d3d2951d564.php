
   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h1>EDIT DATES</h1>
            
			<button id="homeButton" class="btn btn-success">Go to Main Menu</button>

			<!-- Inline JavaScript in Blade Template -->
			<script>
				document.getElementById('homeButton').addEventListener('click', function() {
					window.location.href = "<?php echo e(route('projects.index')); ?>";
				});
			</script>
			
			<div class="col-md-4">
				<div class="card">
					<div class="card-body">
						
						
						
						<form method="post" action="<?php echo e(route('projecthours.datesubmit')); ?>" style="text-align:center">
							<?php echo csrf_field(); ?>
							
							<?php $__currentLoopData = $projecthours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="form-group">
							<label>START DATE</label><br/>
								<input type="text" name="publish_date" value="<?php echo e($post->publish_date); ?>" />								
							</div>
							<div class="form-group">
								<label>END DATE</label><br/>
								<input type="text" name="publishdate_end" value="<?php echo e($post->publishdate_end); ?>" />									
							</div>
							<input type="hidden" name="id" value="<?php echo e($post->id); ?>" />
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
							<input type="submit" class="btn btn-success" value="SUBMIT" />
							
							
						</form>
					</div>
				</div>
			</div>
			
			<div class="col-md-4">
				<div class="card">
					<div class="card-body">			
			
			<?php if($errors->any()): ?>
			<h4><?php echo e($errors->first()); ?></h4>
			<?php endif; ?>
			
				</div>
				</div>
			</div>
			
			
			
           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\workrecord\resources\views/projecthours/edit.blade.php ENDPATH**/ ?>