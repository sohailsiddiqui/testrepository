
   
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
		
		
		<button id="homeButton" class="btn btn-success">Go to Main Menu</button>

		<!-- Inline JavaScript in Blade Template -->
		<script>
			document.getElementById('homeButton').addEventListener('click', function() {
				window.location.href = "<?php echo e(route('projects.index')); ?>";
			});
		</script>

		
		<div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    
                    
                    
                    <form method="post" action="<?php echo e(route('projecthours.starttime')); ?>" style="text-align:center">
                        <?php echo csrf_field(); ?>
						<!--
                        <div class="form-group">
                            
                            <input type="text" name="start" class="form-control" required/>
                        </div>
						-->
                        <div class="form-group">
							<input type="hidden" name="post_id" value="<?php echo e($projects->id); ?>" />
                            <input type="submit" class="btn btn-success" value="START TRACKER" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
		
		
		<div class="col-md-4">
            <div class="card">
                <div class="card-body">                
                    
                    
                    <form method="post" action="<?php echo e(route('projecthours.endtime')); ?>" style="text-align:center">
                        <?php echo csrf_field(); ?>
						<!--
                        <div class="form-group">                           
							
                            <input type="text" name="end" class="form-control" required/>
                        </div>
						-->
						
                        <div class="form-group">
							<input type="hidden" name="post_id" value="<?php echo e($projects->id); ?>" />
                            <input type="submit" class="btn btn-success" value="END TRACKER" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
		
		
		
		
		
		

		
		
		
		
    </div>
</div>




<div class="container">
    <div class="row justify-content-center">
	
			<div class="col-md-12">
            <div class="card">
                <div class="card-body">
				
				<center>

		<?php if($errors->any()): ?>
		<h4><?php echo e($errors->first()); ?></h4>
		<?php endif; ?>
		</center>
		</div>
		</div>
		</div>
    
	
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\workrecord\resources\views/projects/show.blade.php ENDPATH**/ ?>